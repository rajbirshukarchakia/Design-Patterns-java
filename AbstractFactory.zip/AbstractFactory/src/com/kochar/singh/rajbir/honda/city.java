package com.kochar.singh.rajbir.honda;

import com.kochar.singh.rajbir.factory.Vehical;

class city implements Vehical{

    @Override
    public void car() {
        System.out.println("City");
    }

}