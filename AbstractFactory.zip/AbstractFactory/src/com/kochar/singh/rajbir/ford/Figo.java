package com.kochar.singh.rajbir.ford;

import com.kochar.singh.rajbir.factory.Vehical;

public class Figo implements Vehical{
    @Override
    public void car() {
        System.out.println("Figo");
    }
}