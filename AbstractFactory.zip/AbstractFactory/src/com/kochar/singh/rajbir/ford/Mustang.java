package com.kochar.singh.rajbir.ford;

import com.kochar.singh.rajbir.factory.Vehical;

public class Mustang implements Vehical{
    @Override
    public void car() {
        System.out.println("Mustang");
    }
}