package com.kochar.singh.rajbir.vw;

import com.kochar.singh.rajbir.factory.Vehical;
class Ameo implements Vehical{
    @Override
    public void car() {
        System.out.println("Ameo");
    }
}