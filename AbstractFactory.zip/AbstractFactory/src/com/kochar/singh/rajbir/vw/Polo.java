package com.kochar.singh.rajbir.vw;
import com.kochar.singh.rajbir.factory.Vehical;
class Polo implements Vehical{
    @Override
    public void car() {
        System.out.println("Polo");
    }
}