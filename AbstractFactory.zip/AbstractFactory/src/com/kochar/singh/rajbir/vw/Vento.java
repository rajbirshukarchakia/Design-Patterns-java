package com.kochar.singh.rajbir.vw;
import com.kochar.singh.rajbir.factory.Vehical;
class Vento implements Vehical{
    @Override
    public void car() {
        System.out.println("Vento");
    }
}