package com.kochar.singh.rajbir.mahindra;

import com.kochar.singh.rajbir.factory.Vehical;

public class XUV5OO implements Vehical{
    @Override
    public void car() {
        System.out.println("XUV5OO");
    }
}