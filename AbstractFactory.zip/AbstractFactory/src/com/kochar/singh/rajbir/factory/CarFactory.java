package com.kochar.singh.rajbir.factory;

public interface CarFactory {
    Vehical getVehical(Short VEHICAL);
}