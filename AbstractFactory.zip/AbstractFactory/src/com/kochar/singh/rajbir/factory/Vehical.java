package com.kochar.singh.rajbir.factory;

public interface Vehical {
    void car();
}